#ifndef __UTF_POLISH_LADDERS_
#define __UTF_POLISH_LADDERS_
	
	#include <wchar.h>
	#include <stddef.h>
	#include <wctype.h>
	#include <locale.h>

#endif

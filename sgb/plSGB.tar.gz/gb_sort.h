extern void gb_linksort();
extern wchar_t *gb_sorted[];

extern Graph*words();
extern Vertex*find_word();

#define weight u.I 
#define loc a.I
